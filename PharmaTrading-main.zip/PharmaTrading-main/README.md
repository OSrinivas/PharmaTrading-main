# Sample Hardhat Project

This project demonstrates a basic Hardhat use case. It comes with a sample contract, a test for that contract, and a script that deploys that contract.

Try running some of the following tasks:

```shell
npx hardhat help
npx hardhat test
REPORT_GAS=true npx hardhat test
npx hardhat node
npx hardhat run scripts/deploy.js
```

## installation 
### Clone the repo
git clone https://github.com/rishabh480604/PharmaTrading.git
### change directory
cd PharmaTrading
### install hardhat dependency
npm i
### change directory to client
cd client
### install client folder dependency
npm i

### Now project is ready to launch

## Running project
### in project root(pharmaTrading) directory in terminal type below command this will start blockchain server
npx hardhat node 
### in another terminal in same directory run below command, this will deploy contract
npx hardhat run --network localhost scripts/deploy.js  
### change directory to client folder then run frontend
cd client
npm start




